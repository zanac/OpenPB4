#!/usr/bin/env python
# -*- coding: utf-8 -*-

from comfoair import ComfoAir


a =  ComfoAir(host="localhost", port=5656, serialport=None)
a.connect()
print ("ciccio")