#!/bin/sh
mp3file=$1
wavfile=$2
mpg123 -w $wavfile $mp3file

