/*
 * OpenBOR - http://www.LavaLit.com
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE in OpenBOR root for details.
 *
 * Copyright (c) 2004 - 2011 OpenBOR Team
 */

#ifndef CONTROL_PRX_H
#define CONTROL_PRX_H

void getCtrlData(SceCtrlData *data);

#endif
